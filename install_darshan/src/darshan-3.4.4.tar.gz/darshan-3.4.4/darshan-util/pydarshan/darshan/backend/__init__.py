"""The backend package provides implementions for reading
the binary representation of the darshan log file.
The only current implementation uses CFFI which
uses the functions defined in libdarshan-util.so
to read the log.
"""
