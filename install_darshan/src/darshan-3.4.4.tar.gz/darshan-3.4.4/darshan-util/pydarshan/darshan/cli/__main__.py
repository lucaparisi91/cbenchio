if __name__ == "__main__":
    import darshan.cli
    darshan.cli.main()
